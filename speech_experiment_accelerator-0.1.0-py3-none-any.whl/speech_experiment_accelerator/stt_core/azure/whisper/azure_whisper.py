import io

from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai import AzureOpenAI
from pydub import AudioSegment
from speech_experiment_accelerator.config import AzureOpenAIConfig
from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.stt_core.base_speech_to_text_service import (
    BaseSTTService,
)
from speech_experiment_accelerator.utils.machine_learning_client import (
    get_connection_details,
)


class AzureWhisper(BaseSTTService):
    COGNITIVE_SERVICES_TOKEN_URL = "https://cognitiveservices.azure.com/.default"

    def __init__(
        self,
        config: AzureOpenAIConfig,
        storage_client: StorageBase,
        extensions: set[str] = {".wav", ".mp3"},
    ):
        super().__init__(storage_client, extensions)
        ml_client = MLClient.from_config(credential=DefaultAzureCredential())

        connection_details = get_connection_details(ml_client, config.connection_name)

        self.client = AzureOpenAI(
            api_version=config.api_version,
            azure_endpoint=connection_details.endpoint,
            azure_ad_token_provider=get_bearer_token_provider(
                DefaultAzureCredential(), AzureWhisper.COGNITIVE_SERVICES_TOKEN_URL
            ),
        )

        self.deployment = config.whisper_deployment

    def transcribe(self, audio: AudioSegment, **kwargs) -> str:
        buffer = io.BytesIO()
        file_format = kwargs.get("format", "wav")
        audio.export(buffer, format=file_format)
        buffer.seek(0)

        transcription = self.client.audio.transcriptions.create(
            model=self.deployment,
            file=("audio." + file_format, buffer, "audio/" + file_format),
            response_format="text",
        )
        return transcription
