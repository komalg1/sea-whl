import json
import os

from pydub import AudioSegment

from azure.storage.blob import (
    BlobClient,
)
from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.stt_core.base_speech_to_text_service import (
    BaseSTTService,
)

from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)
from speech_experiment_accelerator.utils.common import (
    get_filename,
)
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.stt_core.azure.speech_service.batch_transcription_result import (
    BatchTranscriptionResult,
)

logger = get_logger(__name__)


class AzureSpeechServiceBatch(BaseSTTService):
    def __init__(
        self,
        config: Config,
        speech_client: AzureSpeechClient,
        storage_client: StorageBase,
        extensions: set[str] = {".wav", ".mp3"},
    ):
        super().__init__(storage_client, extensions)
        self._config = config
        self._speech_client = speech_client

    def _find_transcribed_files(self, files: dict) -> dict[str, str]:
        transcription_values = list(
            filter(lambda x: x["kind"] == "Transcription", files)
        )

        transcription_values = {
            get_filename(x["name"]).replace(".json", ""): x
            for x in transcription_values
        }

        file_contents_urls = {
            k: v["links"]["contentUrl"] for k, v in transcription_values.items()
        }
        return file_contents_urls

    def _download_report(self, files: dict) -> dict | None:
        report_files = list(filter(lambda x: x["kind"] == "TranscriptionReport", files))

        if len(report_files) == 0:
            logger.warning("No reports found, skipping download")
            return

        if len(report_files) > 1:
            logger.warning("Several reports found, skipping download")
            return

        report_url = report_files[0].get("links", {}).get("contentUrl")
        if report_url is None:
            logger.warning("No report url provided, skipping download")
            return

        blob_client = BlobClient.from_blob_url(report_url)
        report = blob_client.download_blob().readall()

        filepath = f"{self._config.reporting.folder}/report.json"
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "wb") as f:
            logger.info("Writing report to file: %s", filepath)
            f.write(report)

        return json.loads(report)

    def transcribe_blob_url(
        self,
        audio_to_transcript_mapping: dict[str, str],
        **kwargs,
    ) -> list[tuple[str, str]]:

        transcriptions = self.storage_client.load_transcriptions()
        logger.info("Transcriptions: %s", transcriptions)

        files_url, transcription_url = self._speech_client.start_transcription(
            self.storage_client
        )

        self._speech_client.poll_until_transcription_complete(transcription_url)

        file_contents_urls = self._speech_client.list_transcription_files(files_url)

        transcribed_files = self._find_transcribed_files(file_contents_urls)
        file_contents = {}
        for _, file_content_url in transcribed_files.items():
            source, transcribed_text = self._speech_client.get_file_content(
                file_content_url
            )
            file_contents[get_filename(source)] = transcribed_text

        result = []
        for name in file_contents.keys():
            y_pred = file_contents[name]
            y_true = transcriptions[audio_to_transcript_mapping[name]]
            result.append((y_true, y_pred))

        report = self._download_report(file_contents_urls)

        return BatchTranscriptionResult(result, report)

    def transcribe(self, audio: AudioSegment, **kwargs) -> str:
        raise NotImplementedError(
            "Local transcription is not supported for Azure Speech Service"
        )
