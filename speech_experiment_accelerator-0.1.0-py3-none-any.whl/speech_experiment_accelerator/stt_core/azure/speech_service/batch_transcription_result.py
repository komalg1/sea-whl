from dataclasses import dataclass
from speech_experiment_accelerator.stt_core.transcription_result import (
    TranscriptionResult,
)


@dataclass
class BatchTranscriptionResult(TranscriptionResult):
    report: dict[str, any]
