from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.stt_core.base_speech_to_text_service import (
    BaseSTTService,
)

from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)
from speech_experiment_accelerator.utils.logger import get_logger


from pathlib import Path
from pydub import AudioSegment

logger = get_logger(__name__)


class AzureSpeechServiceRealtime(BaseSTTService):
    def __init__(
        self,
        speech_client: AzureSpeechClient,
        storage_client: StorageBase,
        extensions: set[str] = {".wav"},
    ):
        super().__init__(storage_client, extensions)
        self._speech_client = speech_client

    def transcribe_file(self, audio_file: str | Path, **kwargs) -> str:
        audio_config = self.storage_client.create_audio_config(str(audio_file))
        return self._speech_client.transcribe_realtime(audio_config)

    def transcribe(self, audio: AudioSegment, **kwargs) -> str:
        raise NotImplementedError(
            "Not yet implemented for Azure Speech Service Realtime"
        )

    def transcribe_blob_url(
        self,
        audio_to_transcript_mapping: dict[str, str],
        **kwargs,
    ) -> list[tuple[str, str]]:
        raise NotImplementedError(
            "Not yet implemented for Azure Speech Service Realtime"
        )
