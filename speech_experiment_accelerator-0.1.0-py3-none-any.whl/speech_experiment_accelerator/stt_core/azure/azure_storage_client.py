import tempfile
import io
from cachetools import cached, LRUCache
from pydub import AudioSegment

from azure.storage.blob import (
    ContainerClient,
)
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.utils.common import (
    get_filename,
    is_textfile,
    is_audiofile,
    remove_extension,
)
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.dataset.transcription.transcription import (
    Transcription,
)

logger = get_logger(__name__)


class AzureStorageClient:
    def __init__(self, account_url: str, container: str):
        self.account_url = account_url
        self.container = container

        self.container_client = ContainerClient(
            account_url=self.account_url,
            container_name=self.container,
            credential=DefaultAzureCredential,
        )

        self._files_mapping = self.get_files_mapping()
        self._audio_files = self._get_audio_files()
        self._transcription_files = self._get_transcription_files()

    def _get_audio_files(self) -> list[str]:
        all_files = self.list_files()

        return [
            file
            for file in all_files
            if get_filename(file) in self._files_mapping.keys()
        ]

    def _get_transcription_files(self) -> list[str]:
        all_files = self.list_files()

        return [
            file
            for file in all_files
            if get_filename(file) in self._files_mapping.values()
        ]

    def __hash__(self) -> int:
        return hash(
            (
                self.account_url,
                self.container,
            )
        )

    @cached(LRUCache(maxsize=128), key=lambda self: hash(self))
    def list_files(self) -> list[str]:
        return [blob.name for blob in self.container_client.list_blobs()]

    def _load_blobs(self, filenames: list[str] | None = None) -> dict[str, dict]:
        result = {}

        if filenames is None:
            filenames = self.list_files()

        for filename in filenames:
            blob_data = self.container_client.download_blob(blob=filename).readall()

            suffix = filename.split(".")[-1]
            suffix = f".{suffix}"

            result[filename] = {"data": blob_data, "suffix": suffix}

        return result

    def load_transcriptions(self, filenames: list[str] | None = None) -> dict[str, str]:
        result = {}

        blob_data = self._load_blobs(
            self._transcription_files if filenames is None else filenames
        )

        for filename, blob_data in blob_data.items():
            file_data = blob_data["data"].decode("utf-8")

            with tempfile.NamedTemporaryFile(
                delete=False, suffix=blob_data["suffix"]
            ) as temp_file:
                temp_file.write(file_data.encode())
                temp_file_path = temp_file.name

            transcription = Transcription.from_file(temp_file_path)

            result[get_filename(filename)] = transcription.to_text()

        return result

    def load_audios(
        self, filenames: list[str] | None = None
    ) -> dict[str, AudioSegment]:
        result = {}

        blob_data = self._load_blobs(
            self._audio_files if filenames is None else filenames
        )

        for filename, blob_data in blob_data.items():
            segment = AudioSegment.from_file(
                io.BytesIO(blob_data["data"]), format=blob_data["suffix"]
            )

            result[filename] = segment

        return result

    def get_files_mapping(self, max_files: int | None = None) -> dict[str, str]:
        files = self.list_files()

        logger.info("Found %s files in the container", len(files))

        # get only the top max_files text files
        text_files = [get_filename(file) for file in files if is_textfile(file)]

        audio_files = [get_filename(file) for file in files if is_audiofile(file)]

        # NB -> During load we've opted to store the transcript and audio files with different names
        #       hence we need to map the transcript files to the audio files
        audio_files_index = {
            remove_extension(file).replace("audio", "transcript"): file
            for file in audio_files
        }

        mapping = {}

        for text_file in text_files:
            search_key = remove_extension(text_file)

            if search_key in audio_files_index:
                mapping[audio_files_index[search_key]] = text_file

            if max_files is not None and len(mapping) >= max_files:
                break

        return mapping
