import base64
import os.path
import time
from urllib.parse import urlsplit, urlunsplit

import requests
from azure.ai.ml import MLClient
from azure.ai.ml.entities import AadCredentialConfiguration
from azure.cognitiveservices.speech import AudioConfig, SpeechConfig, SpeechRecognizer
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.exceptions import (
    MultipleFoundException,
    NotFoundException,
)
from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.utils.machine_learning_client import (
    get_connection_details,
)

CONTENT_TYPE_HEADER_KEY = "Content-Type"
APPLICATION_JSON = "application/json"
AUTH_HEADER_KEY = "Authorization"
TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"
TIMEOUT_SECONDS = 30
FOUR_MB_IN_BYTES = 4 * 1024 * 1024

logger = get_logger(__name__)


class AzureSpeechClient:

    def __init__(self, config: Config, speech_service_url: str):
        self.config = config
        self.speech_url = speech_service_url
        self.token_provider = get_bearer_token_provider(
            DefaultAzureCredential(), TOKEN_SCOPE
        )

    @property
    def token(self) -> str:
        """
        Returns a bearer token for Azure Speech Service.

        Returns:
            str: The bearer token.
        """
        return self.token_provider()

    @classmethod
    def from_connection(
        cls, ml_client: MLClient, config: Config
    ) -> "AzureSpeechClient":
        """
        Creates an instance of the AzureSpeechClient class from a connection.

        Args:
            cls (type): The class type of AzureSpeechClient.
            ml_client (MLClient): The MLClient object.
            config (Config): The Config object.

        Returns:
            AzureSpeechClient: An instance of the AzureSpeechClient class.

        Raises:
            ValueError: If the API base URL for the speech service is not set or if
             the speech connection credentials are not of type AadCredentialConfiguration.
        """
        speech_service = get_connection_details(
            ml_client, config.speech_service.connection_name
        )

        if speech_service.api_base is None:
            raise ValueError("API base URL for speech service is not set")
        if not isinstance(speech_service.credentials, AadCredentialConfiguration):
            raise ValueError(
                "Speech connection credentials are not of type AadCredentialConfiguration"
            )

        return cls(config, speech_service.api_base)

    def start_transcription(self, storage_client: StorageBase) -> tuple[str, str]:
        """
        Start a transcription job with the Azure Speech Service.

        :param storage_client: The storage client responsible for hosting the files.
        :return: Tuple of the files URL and the transcription URL.
        """

        body = {
            "model": (
                {
                    "self": self.config.speech_service.user_model_url,
                }
                if self.config.speech_service.user_model_url
                else None
            ),
            "locale": self.config.speech_service.locale,
            "displayName": "Test Transcription",
            "properties": self.config.properties,
        }

        files = storage_client.get_audio_files()
        if files:

            body["contentUrls"] = storage_client.get_audio_files_with_blob_url()

            transcribed_files_list = "\n".join(
                ["Transcribed files ================"]
                + [
                    f"File Name: {f} - URL: {b}"
                    for f, b in zip(files, body["contentUrls"])
                ]
                + ["=================================="]
            )

            logger.info(transcribed_files_list)

        else:
            body["contentContainerUrl"] = storage_client.get_blob_storage_url()

        response = requests.post(
            f"{self.speech_url}/speechtotext/v3.2/transcriptions",
            headers={
                CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
                AUTH_HEADER_KEY: f"Bearer {self.token}",
            },
            json=body,
            timeout=TIMEOUT_SECONDS,
        )
        logger.info("Transcription response: %s", response.json())

        files_url = response.json()["links"]["files"]
        transcription_url = response.json()["self"]
        logger.info(
            "Transcription request made. Transcription URL: %s", transcription_url
        )
        return files_url, transcription_url

    def poll_until_transcription_complete(self, transcription_url: str):
        """
        Poll the Azure Speech Service until the transcription is complete.
        If the transcription fails, an exception is raised. However, if the
        service returns a 429 status code, the polling will continue.

        :param transcription_url: The URL of the transcription to poll.
        :return: None
        """
        while True:
            response = self.__get_transcription_status(transcription_url)
            status_code = response.status_code
            match status_code:
                case 200:

                    status = response.json()["status"]
                    logger.info("Checking status of transcription: %s", status)

                    if status == "Failed":
                        raise Exception(
                            f"Transcription failed. Full response: {response.json()}"
                        )

                    if status == "Succeeded":
                        break

                case 429:
                    logger.info(
                        "Too many requests error when checking the status of the transcription. "
                        "Will retry in %s seconds.",
                        self.config.speech_service.polling_interval_seconds,
                    )
                case _:
                    raise Exception(
                        f"Unexpected response when checking the status of the transcription: "
                        f"{status_code} {response.text}"
                    )

            time.sleep(self.config.speech_service.polling_interval_seconds)

    def list_transcription_files(self, files_url: str) -> dict[str, str]:
        """
        Return a list of the transcribed files. If there are multiple pages of files,
        multiple calls will be made and all files will be returned.

        :param files_url: The URL of the files to list.
        :return: A list of files.
        """

        files = []
        next_files_url = files_url
        while next_files_url:
            response = requests.get(
                next_files_url,
                headers={
                    CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
                    AUTH_HEADER_KEY: f"Bearer {self.token}",
                },
                timeout=TIMEOUT_SECONDS,
            )
            response_json = response.json()
            files.extend(response_json["values"])
            next_files_url = response_json.get("@nextLink")

        return files

    def get_file_content(self, file_contents_url: str) -> tuple[str, str]:
        """
        Get the combined recognized phrases from the transcription file.

        :param file_contents_url: The URL of the transcription file.
        :return: Tuple: source , transcribed text.
        """
        response = requests.get(
            file_contents_url,
            timeout=TIMEOUT_SECONDS,
        )
        response_json = response.json()
        try:
            transcribed_text = response_json["combinedRecognizedPhrases"][0]["display"]
            source = response_json["source"]
            logger.info(
                f"\n\n\nTranscribed text: {transcribed_text} - source: {source}\n\n\n"
            )
            return source, transcribed_text

        except Exception as e:
            logger.error(
                "Error when getting the content of the transcription file. Response: %s",
                response_json,
            )
            raise e

    def __get_transcription_status(self, transcription_url: str) -> requests.Response:
        return requests.get(
            transcription_url,
            headers={
                CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
                AUTH_HEADER_KEY: f"Bearer {self.token}",
            },
            timeout=TIMEOUT_SECONDS,
        )

    def create_or_get_project(self, name: str, locale: str) -> str:
        """
        Create a new project with the given name and locale if it does not already exist. Otherwise, return the URL of
        the existing project. If multiple projects are found with the same name and locale, an exception is raised.

        :param name: The project name.
        :param locale: The project locale.
        :return: The URL of the project.
        """
        response = requests.get(
            f"{self.speech_url}/speechtotext/v3.2/projects",
            params={
                "filter": f"displayName eq '{name}' and locale eq '{locale}'",
            },
            headers={
                AUTH_HEADER_KEY: f"Bearer {self.token}",
            },
            timeout=TIMEOUT_SECONDS,
        )

        projects = response.json()["values"]

        if len(projects) == 0:
            logger.info("Creating project %s with locale %s", name, locale)

            response = requests.post(
                f"{self.speech_url}/speechtotext/v3.2/projects",
                json={
                    "displayName": name,
                    "locale": locale,
                },
                headers={
                    AUTH_HEADER_KEY: f"Bearer {self.token}",
                    CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
                },
                timeout=TIMEOUT_SECONDS,
            )

            logger.debug("Created project %s", name)

            return response.json()["self"]

        if len(projects) > 1:
            raise MultipleFoundException(
                f"Multiple projects found with name '{name}' and locale '{locale}'"
            )

        logger.debug("Project %s with locale %s already exists", name, locale)

        return projects[0]["self"]

    def upload_dataset(self, name: str) -> None:
        """
        Upload the dataset to the Azure Speech Service. This involves creating a project, creating a dataset, uploading
        the dataset blocks, and committing the dataset blocks. The dataset configuration is taken from the configuration
        that corresponds to the given name.

        If the project does not exist, it is created.
        If the dataset file is not found, an NotFoundException is raised.

        :param name: The name of the dataset.
        :return: None
        """
        dataset_config = self.config.training.get_dataset(name)

        logger.info("Creating or getting project")
        project_url = self.create_or_get_project(
            dataset_config.project, dataset_config.locale
        )
        logger.info("Creating dataset '%s' in project %s", name, project_url)
        dataset_url = self.create_dataset(project_url, name)
        logger.info("Uploading dataset blocks for dataset '%s'", name)
        block_ids = self.upload_dataset_blocks(dataset_url, name)
        logger.info("Committing dataset blocks for dataset '%s'", name)
        self.commit_dataset_blocks(dataset_url, block_ids)
        logger.info("Dataset '%s' registered successfully", name)

    def create_dataset(self, project_url: str, name: str) -> str:
        """
        Create a new dataset in the given project with the given name. The dataset kind and locale are taken from the
        configuration that corresponds to the given name.

        :param project_url: The URL of the project to create the dataset in.
        :param name: The name of the dataset.
        :return: The URL of the created dataset.
        """
        dataset_config = self.config.training.get_dataset(name)

        request_url = os.path.join(self.speech_url, "speechtotext", "v3.2", "datasets")
        request_body = {
            "project": {"self": project_url},
            "kind": dataset_config.kind,
            "locale": dataset_config.locale,
            "displayName": name,
        }

        logger.debug(
            f"Making POST request to '{request_url}' with body: {request_body}"
        )

        response = requests.post(
            request_url,
            headers={
                AUTH_HEADER_KEY: f"Bearer {self.token}",
                CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
            },
            json=request_body,
            timeout=TIMEOUT_SECONDS,
        )
        response_json = response.json()

        logger.debug(
            "Create dataset returned response %s with body: %s", response, response_json
        )

        return response_json["self"]

    def upload_dataset_blocks(
        self, dataset_url: str, name: str, buffer_size: int = FOUR_MB_IN_BYTES
    ) -> list[str]:
        """
        Upload the dataset blocks to the given dataset URL. The dataset path is taken from the configuration that
        corresponds to the given name. If the dataset file is not found, an NotFoundException is raised.

        :param dataset_url: The URL of the dataset to upload the blocks to.
        :param name: The name of the dataset.
        :return: A list containing the block IDs uploaded.
        """
        dataset_config = self.config.training.get_dataset(name)

        if not os.path.isfile(dataset_config.path):
            raise NotFoundException(
                f"Training dataset file not found at '{dataset_config.path}'"
            )

        block_ids = []
        i = 0
        with open(dataset_config.path, "rb") as data:
            file_contents = data.read(buffer_size)

            while len(file_contents) != 0:
                block_id = base64.b64encode("{:08d}".format(i).encode("utf-8")).decode(
                    "utf-8"
                )
                block_ids.append(block_id)
                self.__upload_block(dataset_url, file_contents, block_id)

                file_contents = data.read(buffer_size)
                i += 1

        return block_ids

    def __upload_block(self, dataset_url: str, data: bytes, block_id: str) -> None:
        request_url = os.path.join(dataset_url, "blocks")
        request_params = {"blockid": block_id}

        logger.debug(
            f"Making PUT request to '{request_url}' with params: {request_params}"
        )

        response = requests.put(
            request_url,
            params=request_params,
            headers={
                AUTH_HEADER_KEY: f"Bearer {self.token}",
                CONTENT_TYPE_HEADER_KEY: "application/octet-stream",
            },
            data=data,
        )

        logger.debug("Upload blocks returned response %s", response)

    def commit_dataset_blocks(self, dataset_url: str, block_ids: list[str]) -> None:
        """
        Commit the dataset blocks to the given dataset URL. This triggers the processing of the dataset blocks in
        Azure Speech Service.

        :param dataset_url: The URL of the dataset to commit the blocks to.
        :param block_ids: A list of block IDs to commit.
        :return: None
        """
        request_url = os.path.join(dataset_url, "blocks:commit")
        request_body = [{"kind": "Latest", "id": block_id} for block_id in block_ids]
        logger.debug(
            f"Making POST request to '{request_url}' with body: {request_body}"
        )

        response = requests.post(
            request_url,
            headers={
                AUTH_HEADER_KEY: f"Bearer {self.token}",
                CONTENT_TYPE_HEADER_KEY: APPLICATION_JSON,
            },
            json=request_body,
            timeout=TIMEOUT_SECONDS,
        )

        logger.debug("Commit dataset blocks returned response: %s", response)

    def transcribe_realtime(self, audio_config: AudioConfig) -> str:
        def recognized(evt):
            nonlocal done, result
            result += " " + evt.result.text

        def stop_cb(evt):
            """callback that stops continuous recognition upon receiving an event `evt`"""
            speech_recognizer.stop_continuous_recognition()

            nonlocal done, result
            result += " " + evt.result.text

            done = True

        speech_recognizer = self._get_speech_recognizer(audio_config)

        result = ""
        done = False

        speech_recognizer.recognized.connect(recognized)
        speech_recognizer.session_stopped.connect(stop_cb)
        speech_recognizer.canceled.connect(stop_cb)

        speech_recognizer.start_continuous_recognition()
        while not done:
            time.sleep(0.5)

        logger.info("\n\n\nTranscribed text: %s\n\n\n", result)
        return result

    def _get_realtime_endpoint(self) -> str:
        hostname = urlsplit(self.speech_url).hostname

        return urlunsplit(
            (
                "wss",
                hostname,
                "/stt/speech/recognition/conversation/cognitiveservices/v1",
                "",
                "",
            )
        )

    def _get_speech_recognizer(self, audio_config: AudioConfig) -> SpeechRecognizer:
        endpoint = self._get_realtime_endpoint()

        speech_config = SpeechConfig(endpoint=endpoint)
        speech_config.authorization_token = self.token

        return SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
