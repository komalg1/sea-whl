import io
from abc import ABC, abstractmethod
from pathlib import Path
from pydub import AudioSegment
from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.stt_core.transcription_result import (
    TranscriptionResult,
)


class BaseSTTService(ABC):
    def __init__(
        self,
        storage_client: StorageBase,
        extensions: set[str] = {".wav", ".mp3"},
        **kwargs,
    ):
        self._extensions = extensions
        self.storage_client = storage_client

    def transcribe_blob_url(
        self,
        audio_to_transcript_mapping: dict[str, str],
        **kwargs,
    ) -> list[tuple[str, str]]:

        transcriptions = self.storage_client.load_transcriptions()
        audio_files = self.storage_client.load_audio_files()

        predicted_transcriptions = {}
        for filename, audio in audio_files.items():
            if filename in audio_to_transcript_mapping:
                path_format = Path(filename).suffix.strip(".")
                predicted_transcriptions[filename] = self.transcribe(
                    audio, format=path_format, **kwargs
                )

        result = []
        for af, tf in audio_to_transcript_mapping.items():
            y_true = transcriptions[tf]
            y_pred = predicted_transcriptions[af]

            result.append((y_true, y_pred))

        return TranscriptionResult(result)

    def transcribe_directory(
        self, audio_dir: str | Path, max_files: int | None = None, **kwargs
    ) -> list[str]:
        if isinstance(audio_dir, str):
            audio_dir = Path(audio_dir)

        result = []
        for file in audio_dir.iterdir():
            if file.suffix in self._extensions:
                result.append(self.transcribe_file(file, **kwargs))
            if max_files is not None and len(result) >= max_files:
                break

        return result

    def transcribe_file(self, audio_file: str | Path, **kwargs) -> str:
        if isinstance(audio_file, str):
            audio_file = Path(audio_file)

        if audio_file.suffix not in self._extensions:
            raise ValueError(f"File extension {audio_file.suffix} not supported")

        audio_segment = AudioSegment.from_file(
            io.BytesIO(audio_file.read_bytes()), format=audio_file.suffix[1:]
        )

        return self.transcribe(
            audio_segment, format=audio_file.suffix.strip("."), **kwargs
        )

    @abstractmethod
    def transcribe(self, audio: AudioSegment, **kwargs) -> str:
        raise NotImplementedError
