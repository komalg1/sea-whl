import whisper
import numpy as np

from pydub import AudioSegment

from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.stt_core.base_speech_to_text_service import (
    BaseSTTService,
)

MAX_INT16 = 32768.0


class Whisper(BaseSTTService):

    def __init__(
        self,
        storage_client: StorageBase,
        extensions: set[str] = {".wav", ".mp3"},
        chunk_size_seconds=28,
        model_id="small",
        fp16=False,
    ):
        super().__init__(storage_client, extensions)
        self._chunk_size_seconds = chunk_size_seconds
        self._model = whisper.load_model(model_id)
        self._fp16 = fp16

    def transcribe(self, audio: AudioSegment, **kwargs) -> str:
        chunks = []
        for i in range(0, len(audio), self._chunk_size_seconds * 1000):
            chunks.append(audio[i : i + self._chunk_size_seconds * 1000])

        transcriptions = []
        for i, chunk in enumerate(chunks):
            chunk_repr = self._chunk_to_numpy(chunk)
            result = self._model.transcribe(chunk_repr, fp16=self._fp16)

            transcriptions.append(result["text"])

        full_transcription = " ".join(transcriptions)

        return full_transcription

    def _chunk_to_numpy(self, chunk: AudioSegment) -> np.ndarray:
        raw_data = chunk.raw_data
        if raw_data is None:
            raise ValueError("raw_data is None")

        return (
            np.frombuffer(raw_data, np.int16).flatten().astype(np.float32) / MAX_INT16
        )
