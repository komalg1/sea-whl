from dataclasses import dataclass


@dataclass
class TranscriptionResult:
    transcriptions: list[tuple[str, str]]
