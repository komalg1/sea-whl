from dataclasses import dataclass, field
import os
import pympi
import pympi.Elan
import textgrids
import pylangacq as pla
from pylangacq.objects import Utterance


def _convert_to_seconds(x: float) -> float:
    return x / 1000.0


@dataclass
class TranscriptionSegment:
    start: float
    duration: float
    end: float
    speaker: str
    annotation: str


@dataclass
class Transcription:
    segments: list[TranscriptionSegment] = field(default_factory=list)
    total_duration: float = 0.0
    number_of_characters: int = 0

    @classmethod
    def from_eaf(cls, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        eaf = pympi.Elan.Eaf(path)

        segments: list[TranscriptionSegment] = []
        total_duration: float = 0.0
        number_of_characters: int = 0

        for tier in eaf.get_tier_names():
            for start, end, phrase in eaf.get_annotation_data_for_tier(tier):
                speaker = eaf.get_parameters_for_tier(tier).get("PARTICIPANT", tier)

                new_segment = TranscriptionSegment(
                    start=_convert_to_seconds(start),
                    duration=_convert_to_seconds(end - start),
                    end=_convert_to_seconds(end),
                    speaker=speaker,
                    annotation=phrase,
                )

                total_duration += new_segment.duration
                number_of_characters += len(new_segment.annotation)

                segments.append(new_segment)

        segments = list(sorted(segments, key=lambda x: x.start))

        return cls(
            segments=segments,
            total_duration=total_duration,
            number_of_characters=number_of_characters,
        )

    @classmethod
    def from_textgrid(cls, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        tg = textgrids.TextGrid(path)
        segments: list[TranscriptionSegment] = []
        total_duration: float = 0.0
        number_of_characters: int = 0

        for tier_name in tg.keys():
            tier: textgrids.Tier = tg[tier_name]
            # This is here purely for type hinting
            interval: textgrids.Interval
            for interval in tier:

                new_segment = TranscriptionSegment(
                    start=interval.xmin,
                    duration=interval.dur,
                    end=interval.xmax,
                    speaker=tier_name,
                    annotation=interval.text,
                )

                total_duration += new_segment.duration
                number_of_characters += len(new_segment.annotation)

                segments.append(new_segment)

        segments = list(sorted(segments, key=lambda x: x.start))

        return cls(
            segments=segments,
            total_duration=total_duration,
            number_of_characters=number_of_characters,
        )

    @classmethod
    def from_cha(cls, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        chat_data = pla.read_chat(path)
        segments: list[TranscriptionSegment] = []
        total_duration: float = 0.0
        number_of_characters: int = 0

        utterances = chat_data.utterances()
        if isinstance(utterances[0], list):
            utterances = sum(utterances, [])

        for utterance in utterances:
            # This is here purely for type hinting
            utterance: Utterance = utterance
            start = utterance.time_marks[0] if utterance.time_marks else 0.0
            end = utterance.time_marks[1] if utterance.time_marks else 0.0
            phrase = " ".join([token.word for token in utterance.tokens])
            speaker = utterance.participant

            new_segment = TranscriptionSegment(
                start=_convert_to_seconds(start),
                duration=_convert_to_seconds(end - start),
                end=_convert_to_seconds(end),
                speaker=speaker,
                annotation=phrase,
            )

            total_duration += new_segment.duration
            number_of_characters += len(new_segment.annotation)

            segments.append(new_segment)

        segments = list(sorted(segments, key=lambda x: x.start))

        return cls(
            segments=segments,
            total_duration=total_duration,
            number_of_characters=number_of_characters,
        )

    @classmethod
    def from_txt(cls, path: str):
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        with open(path, "r") as f:
            text = f.readlines()

        segments: list[TranscriptionSegment] = [
            TranscriptionSegment(
                start=0,
                duration=1.0,
                end=1.0,
                speaker="unknown",
                annotation="\n".join(text).strip(),
            )
        ]
        total_duration: float = 1.0

        number_of_characters: int = sum([len(item) for item in text], 0)

        return cls(
            segments=segments,
            total_duration=total_duration,
            number_of_characters=number_of_characters,
        )

    @classmethod
    def from_file(cls, path: str):
        if path.lower().endswith(".eaf"):
            return cls.from_eaf(path)
        elif path.lower().endswith(".textgrid"):
            return cls.from_textgrid(path)
        elif path.lower().endswith(".cha"):
            return cls.from_cha(path)
        elif path.lower().endswith(".txt"):
            return cls.from_txt(path)
        else:
            raise ValueError(f"Unsupported file type: {path}")

    def to_text(self) -> str:
        return "\n".join([segment.annotation for segment in self.segments])
