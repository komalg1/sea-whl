import io
import os
import re
import time
from typing import Any

import yaml
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator

from speech_experiment_accelerator.exceptions import (
    ValidationException,
    NotFoundException,
)

DEFAULT_PROJECT_NAME = "Speech Experiment Accelerator"


class ExperimentConfig(BaseModel):
    name: str = Field(
        description="The name of the experiment you wish to run.", min_length=1
    )
    custom_config: dict[str, Any] | None = Field(
        description="Use this to specify a custom configuration for the experiment. This will "
        "be passed to the experiment as a dictionary.",
        default={},
    )
    data_asset_name: str = Field(
        description="Use this to specify a data asset to use for the experiment. ",
        min_length=1,
    )
    data_asset_version: str | None = Field(
        description="Use this to specify a data asset version to use for the experiment. ",
        default=None,
    )

    max_files: int | None = Field(
        description="The maximum number of files to process. If not specified, all files "
        "will be processed.",
        default=None,
    )


class AzureOpenAIConfig(BaseModel):
    api_version: str
    whisper_deployment: str = "whisper"
    llm_deployment: str = "gpt-4o"
    connection_name: str = "openai-connection"


class SpeechServiceConfig(BaseModel):
    connection_name: str = Field(
        description="The name of the connection to use for the speech service. "
        "If not provided, the default connection will be used.",
        default="speech-connection",
    )
    polling_interval_seconds: float = 10.0
    user_model_url: str | None = Field(
        description="Use this to specify a custom model URL to use for the experiment. If not"
        " provided, the default model will be used.",
        default=None,
    )
    locale: str = Field(
        description="The locale of the audio. If not provided, the default locale (en-US) will be used.",
        default="en-US",
    )

    @field_validator("connection_name", mode="before")
    @classmethod
    def validate_connection_name(cls, value):
        if value is None or not value.strip():
            raise ValueError(
                "Config validation failed: 'speech_service.connection_name' is blank"
            )
        return value


class Dataset(BaseModel):
    dataset_name: str = "PolyAI/minds14"
    dataset_config: str = "en-US"
    train_test_split_ratio: float = 0.2
    train_validation_split_ratio: float = 0.25
    train_path: str = "azureml://datastores/train/paths/minds14/train"
    validate_path: str = "azureml://datastores/validate/paths/minds14/validate"
    test_path: str = "azureml://datastores/test/paths/minds14/test"
    audio_extension: str = ".wav"


class CustomModelConfig(BaseModel):
    description: str | None = Field(
        description="The description of the model.", default=None
    )
    project: str = Field(
        description="The name of the project in which the model will be created. "
        "Project will be created if it does not exist.",
        default=DEFAULT_PROJECT_NAME,
    )
    locale: str = Field(description="The locale of the model.")
    base_model: str | None = Field(
        description="The name of the base model to use. "
        "If not specified, the default base model for the locale is used.",
        default=None,
    )
    datasets: list[str] = Field(
        description="The names of the datasets to train the model with.", min_length=1
    )
    properties: dict[str, Any] | None = Field(
        description="Additional properties to pass to the model.", default=None
    )


class TrainingDatasetConfig(BaseModel):
    project: str = Field(
        description="The name of the project in which the dataset will be created. "
        "Project will be created if it does not exist.",
        default=DEFAULT_PROJECT_NAME,
    )
    locale: str = Field(description="The locale of the dataset.")
    kind: str = Field(description="The kind of the dataset.")
    path: str = Field(description="The path to the dataset.")


class TrainingConfig(BaseModel):
    custom_models: dict[str, CustomModelConfig] = {}
    datasets: dict[str, TrainingDatasetConfig] = {}

    def get_dataset(self, name: str) -> TrainingDatasetConfig:
        if name not in self.datasets:
            raise NotFoundException(
                f"Training dataset configuration not found for '{name}'"
            )
        return self.datasets[name]


class ReportingConfig(BaseModel):
    folder: str = "outputs"
    enabled: bool = True


class JobConfig(BaseModel):
    compute: str | None = None
    name_prefix: str | None = None
    experiment_name: str = "speech-experiment-accelerator"

    def get_name(self) -> str | None:
        return (
            f"{self.name_prefix}-{str(int(time.time() * 1000))}"
            if self.name_prefix
            else None
        )


class Config(BaseModel):
    experiment: ExperimentConfig
    azure_openai: AzureOpenAIConfig | None = None
    speech_service: SpeechServiceConfig
    training: TrainingConfig = TrainingConfig()
    properties: dict = {}
    job: JobConfig = JobConfig()
    dataset: Dataset | None = None
    reporting: ReportingConfig = ReportingConfig()

    @model_validator(mode="before")
    @classmethod
    def replace_env_vars(cls, values):
        def replace_env_var(value):
            if (
                isinstance(value, str)
                and value.startswith("${")
                and value.endswith("}")
            ):
                # Regex to match & capture placeholders in the form of ${VARIABLE} or ${VARIABLE:-default} in a string
                path_matcher = re.compile(r"\$\{([\w]+)(:-.*)?\}")
                match = path_matcher.match(value)
                variable, default = match.groups()
                if default:
                    default = default[2:]
                return os.environ.get(variable, default)
            else:
                if isinstance(value, dict):
                    return {key: replace_env_var(value) for key, value in value.items()}
            return value

        return {key: replace_env_var(value) for key, value in values.items()}

    @classmethod
    def from_yaml(cls, yaml_string: str):
        try:
            yaml_dict = yaml.safe_load(yaml_string)
        except yaml.YAMLError as e:
            raise ValidationException("Config file is invalid") from e
        if yaml_dict is None or not isinstance(yaml_dict, dict):
            raise ValidationException("Config file is empty or not properly structured")
        try:
            return cls(**yaml_dict)
        except ValidationError as e:
            raise ValidationException(f"Config validation error: {str(e)}") from e


def load_config(config_file: io.TextIOWrapper | str):
    yaml_string = (
        config_file.read() if isinstance(config_file, io.TextIOWrapper) else config_file
    )
    return Config.from_yaml(yaml_string)
