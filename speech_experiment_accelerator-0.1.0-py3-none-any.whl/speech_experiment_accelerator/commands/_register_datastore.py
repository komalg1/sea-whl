import click
import io

from azure.ai.ml import command, Output, MLClient
from azure.ai.ml.entities import ManagedIdentityConfiguration
from azure.ai.ml.constants import AssetTypes, InputOutputModes
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.config import load_config
from speech_experiment_accelerator.exceptions import ValidationException
from speech_experiment_accelerator.utils.common import get_repo_root, _write_to_file


@click.command()
@click.option(
    "--config-file",
    required=False,
    help="Path to config file",
    type=click.File("r"),
    default="config.yaml",
)
@click.option(
    "--azureml-config-file",
    required=False,
    help="Path to AzureML config file",
    type=click.File("r"),
    default=None,
)
def register_datastore(
    config_file: io.TextIOWrapper, azureml_config_file: io.TextIOWrapper | None
):
    config_yaml = config_file.read()

    config = load_config(config_yaml)
    if config.dataset is None:
        raise ValidationException("Dataset configuration is missing.")
    root_path = get_repo_root()
    config_dir, config_filename = "aml_config", "config.yaml"
    if not root_path:
        raise ValidationException("Root path is not found.")
    _write_to_file(config_yaml, root_path, config_dir, config_filename)

    output_mode = InputOutputModes.RW_MOUNT

    outputs = {
        "train": Output(
            type=AssetTypes.URI_FOLDER,
            path=config.dataset.train_path,
            mode=output_mode,
            name="train",
        ),
        "validate": Output(
            type=AssetTypes.URI_FOLDER,
            path=config.dataset.validate_path,
            mode=output_mode,
            name="validate",
        ),
        "test": Output(
            type=AssetTypes.URI_FOLDER,
            path=config.dataset.test_path,
            mode=output_mode,
            name="test",
        ),
    }

    azureml_config_file = azureml_config_file.read() if azureml_config_file else None
    ml_client = MLClient.from_config(
        credential=DefaultAzureCredential(), path=azureml_config_file
    )

    command_args = [
        "pip install . && python ./scripts/load_dataset.py",
        f"--config-file {config_dir}/{config_filename}",
        "--train-path ${{outputs.train}}",
        "--validate-path ${{outputs.validate}}",
        "--test-path ${{outputs.test}}",
    ]

    job = command(
        code=root_path,
        command=" ".join(command_args),
        outputs=outputs,
        environment="AzureML-AI-Studio-Development@latest",
        compute=config.job.compute,
        identity=ManagedIdentityConfiguration(),
        name=config.job.get_name(),
        experiment_name="RegisterDataAssets",
    )

    ml_client.create_or_update(job)
