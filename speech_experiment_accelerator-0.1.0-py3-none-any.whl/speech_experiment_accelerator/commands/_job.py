import io
import os

import click
from azure.ai.ml import MLClient, command
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.config import load_config
from speech_experiment_accelerator.utils.machine_learning_client import get_job_input


def _get_repository_root_path() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def _write_to_file(config_yaml: str, *path: str):
    with open(os.path.join(*path), "w", encoding="utf-8") as f:
        f.write(config_yaml)


@click.command()
@click.option(
    "--config-file",
    required=False,
    help="Path to config file",
    type=click.File("r"),
    default="config.yaml",
)
@click.option(
    "--azureml-config-file",
    required=False,
    help="Path to AzureML config file",
    type=click.File("r"),
    default=None,
)
def job(config_file: io.TextIOWrapper, azureml_config_file: io.TextIOWrapper | None):
    config_yaml = config_file.read()

    config = load_config(config_yaml)

    root_path = _get_repository_root_path()
    config_dir, config_filename = "aml_config", "config.yaml"

    # Write config file to /aml_config/config.yaml
    _write_to_file(config_yaml, root_path, config_dir, config_filename)

    azureml_config_file = azureml_config_file.read() if azureml_config_file else None
    ml_client = MLClient.from_config(DefaultAzureCredential(), path=azureml_config_file)

    job_input = get_job_input(ml_client, config.experiment)
    input_path_argument = " --input-path '${{inputs.data}}' " if job_input else ""

    command_job = command(
        code=root_path,
        name=config.job.get_name(),
        experiment_name=config.job.experiment_name,
        command=(
            "pip install . && "
            + "sudo apt update && sudo apt install -y ffmpeg && "
            + f"sea run --config-file {config_dir}/{config_filename}"
            + input_path_argument
        ),
        environment="AzureML-AI-Studio-Development@latest",
        compute=config.job.compute,
        inputs=job_input,
    )

    ml_client.jobs.create_or_update(command_job)
