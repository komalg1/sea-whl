import io

import click

from speech_experiment_accelerator.config import load_config
from speech_experiment_accelerator.exceptions import ValidationException
from speech_experiment_accelerator.experiments.examples.batch_transcription_experiment import (
    BatchTranscriptionExperiment,
)
from speech_experiment_accelerator.experiments.examples.batch_transcription_with_translation_experiment import (
    BatchTranscriptionWithTranslationExperiment,
)
from speech_experiment_accelerator.experiments.examples.whisper_local_experiment import (
    WhisperLocalExperiment,
)
from speech_experiment_accelerator.experiments.examples.realtime_transcription_experiment import (
    RealtimeTranscriptionExperiment,
)
from speech_experiment_accelerator.experiments.examples.whisper_azure_experiment import (
    WhisperAzureExperiment,
)
from speech_experiment_accelerator.utils.logger import get_logger

# add more imports here


logger = get_logger(__name__)


@click.command()
@click.option(
    "--config-file",
    required=False,
    help="Path to config file",
    type=click.File("r"),
    default="config.yaml",
)
@click.option(
    "--azureml-config-file",
    required=False,
    help="Path to AzureML config file",
    type=click.File("r"),
    default=None,
)
@click.option(
    "--input-path",
    required=False,
    help="Path to data input folder. This will be a mounted path when called from a job. You can "
    "also pass an Azure Machine Learning Datastore URI (azureml://) if you want to run this on your "
    "local machine, but keeping the data in the cloud. If you leave this blank, the data will be "
    "loaded using the data asset name from the config file. "
    "https://learn.microsoft.com/en-us/azure/machine-learning/concept-data?view=azureml-api-2",
    type=click.STRING,
    default=None,
)
def run(
    config_file: io.TextIOWrapper,
    azureml_config_file: io.TextIOWrapper | None,
    input_path: str | None,
):
    config = load_config(config_file)

    experiments = {
        "batch-transcription": lambda: BatchTranscriptionExperiment(
            config, azureml_config_file, input_path
        ),
        "batch-transcription-with-translation": lambda: BatchTranscriptionWithTranslationExperiment(
            config, azureml_config_file, input_path
        ),
        "whisper-local": lambda: WhisperLocalExperiment(
            config, azureml_config_file, input_path
        ),
        "whisper-azure": lambda: WhisperAzureExperiment(
            config, azureml_config_file, input_path
        ),
        "realtime-transcription": lambda: RealtimeTranscriptionExperiment(
            config, azureml_config_file, input_path
        ),
        # add more experiments here
    }

    configured_experiment = config.experiment.name
    if configured_experiment not in experiments:
        raise ValidationException(
            f"Experiment {configured_experiment} not found in available experiments: {experiments.keys()}"
        )

    logger.info("Running experiment %s", config.experiment)
    experiments[configured_experiment]().run()
