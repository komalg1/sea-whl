# flake8: noqa
from speech_experiment_accelerator.commands._job import job
from speech_experiment_accelerator.commands._run import run
from speech_experiment_accelerator.commands._model import model
from speech_experiment_accelerator.commands._register_datastore import (
    register_datastore,
)
