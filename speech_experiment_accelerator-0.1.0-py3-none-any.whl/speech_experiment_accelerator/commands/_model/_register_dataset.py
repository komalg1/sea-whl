import io
import logging
import click

from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.config import load_config, Config
from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)

logger = logging.getLogger(__name__)


def _get_speech_client(config: Config) -> AzureSpeechClient:
    ml_client = MLClient.from_config(credential=DefaultAzureCredential())
    return AzureSpeechClient.from_connection(ml_client, config)


@click.command()
@click.option(
    "--config-file",
    help="Path to config file",
    type=click.File("r"),
    default="config.yaml",
)
@click.option(
    "--name",
    "-n",
    help="Name of the dataset to upload and register",
    type=str,
    required=True,
)
def register_dataset(config_file: io.TextIOWrapper, name: str):
    logger.info("Command to register dataset invoked")
    config = load_config(config_file)

    azure_speech_client = _get_speech_client(config)
    azure_speech_client.upload_dataset(name)
