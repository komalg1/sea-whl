import io
import logging

import click
import requests
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.config import Config, CustomModelConfig, load_config
from speech_experiment_accelerator.exceptions import (
    MultipleFoundException,
    NotFoundException,
    ResourceExistsException,
    TrainingFailureException,
)
from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)

logger = logging.getLogger(__name__)


def _get_speech_client(config: Config) -> AzureSpeechClient:
    ml_client = MLClient.from_config(credential=DefaultAzureCredential())
    return AzureSpeechClient.from_connection(ml_client, config)


def _get_request_headers(client: AzureSpeechClient) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {client.token}",
    }


def _return_self_dict(obj: dict) -> dict[str, str]:
    return {
        "self": obj["self"],
    }


def check_model_does_not_exist(
    url: str, name: str, locale: str, headers: dict[str, str]
):
    response = requests.get(
        f"{url}/speechtotext/v3.2/models",
        headers=headers,
        params={
            "filter": f"displayName eq '{name}' and locale eq '{locale}'",
        },
        timeout=10,
    )

    if len(response.json()["values"]) > 0:
        raise ResourceExistsException(
            f"Model with name {name} and locale {locale} already exists"
        )


def get_base_model(
    url: str, name: str, locale: str, headers: dict[str, str]
) -> dict[str, str]:
    response = requests.get(
        f"{url}/speechtotext/v3.2/models/base",
        headers=headers,
        params={
            "filter": f"displayName eq '{name}' and locale eq '{locale}'",
        },
        timeout=10,
    )

    base_models = response.json()["values"]

    if len(base_models) == 0:
        raise NotFoundException(f"Base model {name} with locale {locale} not found")

    return _return_self_dict(base_models[0])


def get_dataset(
    url: str, name: str, locale: str, headers: dict[str, str]
) -> dict[str, str]:
    response = requests.get(
        f"{url}/speechtotext/v3.2/datasets",
        params={
            "filter": f"displayName eq '{name}' and locale eq '{locale}'",
        },
        headers=headers,
        timeout=10,
    )

    datasets = response.json()["values"]

    if len(datasets) == 0:
        raise NotFoundException(f"Dataset {name} with locale {locale} not found")

    if len(datasets) > 1:
        raise MultipleFoundException(
            f"Multiple datasets found with name {name} and locale {locale}"
        )

    return _return_self_dict(datasets[0])


def create_model(
    url: str,
    name: str,
    model: CustomModelConfig,
    project_url: str,
    base_model: dict[str, str] | None,
    datasets: list[dict[str, str]],
    headers: dict[str, str],
):
    response = requests.post(
        f"{url}/speechtotext/v3.2/models",
        headers=headers,
        json={
            "displayName": name,
            "description": model.description,
            "project": {"self": project_url},
            "baseModel": base_model,
            "datasets": datasets,
            "locale": model.locale,
            "properties": model.properties,
        },
        timeout=10,
    )

    if response.status_code == 201:
        logger.info(
            "Custom model %s training started. "
            "Progress can be tracked in the Speech Studio at https://speech.microsoft.com/portal/customspeech",
            name,
        )
    else:
        logger.error(
            "Failed to start training for custom model %s. Status code: %s. Response: %s",
            name,
            response.status_code,
            response.json(),
        )

        raise TrainingFailureException(
            f"Failed to start training for custom model {name}"
        )


@click.command()
@click.option(
    "--config-file",
    help="Path to config file",
    type=click.File("r"),
    default="config.yaml",
)
@click.option(
    "--name",
    "-n",
    help="Name of the custom model to train",
    type=str,
    required=True,
)
def train(config_file: io.TextIOWrapper, name: str):
    config = load_config(config_file)

    model = config.training.custom_models.get(name)

    if model is None:
        raise NotFoundException(
            f"Custom model with name {name} not found in config file"
        )

    speech_client = _get_speech_client(config)
    headers = _get_request_headers(speech_client)

    check_model_does_not_exist(speech_client.speech_url, name, model.locale, headers)

    project_url = speech_client.create_or_get_project(model.project, model.locale)

    if model.base_model is not None:
        base_model = get_base_model(
            speech_client.speech_url, model.base_model, model.locale, headers
        )
    else:
        base_model = None

    datasets = [
        get_dataset(speech_client.speech_url, name, model.locale, headers)
        for name in model.datasets
    ]

    create_model(
        speech_client.speech_url,
        name,
        model,
        project_url,
        base_model,
        datasets,
        headers,
    )
