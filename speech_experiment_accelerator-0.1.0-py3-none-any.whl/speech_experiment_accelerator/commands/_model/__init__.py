import click

from speech_experiment_accelerator.commands._model._train import train
from speech_experiment_accelerator.commands._model._register_dataset import (
    register_dataset,
)


@click.group()
def model():
    pass


model.add_command(train)
model.add_command(register_dataset)

__all__ = [
    "model",
]
