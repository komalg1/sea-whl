from azure.ai.ml import MLClient
from azure.ai.ml.entities import Environment, BuildContext
from azure.identity import DefaultAzureCredential

env_docker_context = Environment(
    build=BuildContext(path="./build-context"),
    name="custom-sea-env",
    description="Environment created from a Docker context.",
)
ml_client = MLClient.from_config(DefaultAzureCredential())
ml_client.environments.create_or_update(env_docker_context)
