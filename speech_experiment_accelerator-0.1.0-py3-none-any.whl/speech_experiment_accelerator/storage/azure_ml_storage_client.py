from azureml.fsspec import AzureMachineLearningFileSystem
from azure.ai.ml import MLClient
from azure.cognitiveservices.speech import AudioConfig
from pydub import AudioSegment

from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.utils.common import get_filename
from speech_experiment_accelerator.utils.logger import get_logger

logger = get_logger(__name__)


class AzureMLStorageClient(StorageBase):
    def __init__(
        self,
        ml_client: MLClient,
        data_asset_name: str,
        data_asset_version: str | None = None,
        preserve_path_in_mapping: bool = True,
        max_files: int | None = None,
    ):
        super().__init__(
            ml_client,
            data_asset_name,
            preserve_path_in_mapping,
            max_files,
        )
        # We use the data asset to attach a file system.
        data_asset = ml_client.data.get(
            data_asset_name,
            version=data_asset_version,
            label="latest" if data_asset_version is None else None,
        )
        if data_asset is None:
            raise ValueError(f"Data asset {data_asset_name} not found.")
        if data_asset.path is None:
            raise ValueError(f"Data asset {data_asset_name} has no path.")
        self.file_system = AzureMachineLearningFileSystem(data_asset.path)

    def list_files(self, preserve_path: bool) -> list[str]:
        # Specifying we dont want detail - just gives the filename
        if preserve_path:
            return self.file_system.ls(path="", detail=False)
        return [
            get_filename(file) for file in self.file_system.ls(path="", detail=False)
        ]

    def load_transcriptions(self) -> dict[str, str]:
        result = {}

        for filename in self._get_transcription_files():
            result[filename] = self.file_system.read_text(
                path=filename, encoding="utf-8"
            ).decode("utf-8")

        return result

    def load_audio_files(self) -> dict[str, AudioSegment]:
        result = {}

        for filename in self.get_audio_files():
            with self.file_system.open(filename, "rb") as f:
                segment = AudioSegment.from_file(f, format=filename.split(".")[-1])

            result[filename] = segment

        return result

    def create_audio_config(self, audio_file_name: str) -> AudioConfig:
        with self.file_system.read_bytes(audio_file_name, "rb") as f:
            return AudioConfig(stream=f)
