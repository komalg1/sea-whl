from abc import ABC, abstractmethod

from azure.ai.ml import MLClient
from azure.cognitiveservices.speech import AudioConfig
from pydub import AudioSegment

from speech_experiment_accelerator.utils.common import (
    get_filename,
    is_audiofile,
    is_textfile,
    remove_extension,
)
from speech_experiment_accelerator.utils.logger import get_logger

logger = get_logger(__name__)


class StorageBase(ABC):
    def __init__(
        self,
        ml_client: MLClient,
        data_asset_name: str,
        preserve_path_in_mapping: bool = True,
        max_files: int | None = None,
    ):
        self._ml_client = ml_client
        self._data_asset_name = data_asset_name
        self._max_files = max_files
        self._preserve_path_in_mapping = preserve_path_in_mapping

    def get_blob_storage_url(self) -> str:
        """
        Returns the URL for accessing the blob storage.

        Returns:
            str: The URL for accessing the blob storage.
        """
        # We use the datastore to obtain the underlying blob storage URL.
        # We don't care about the version of the data asset.
        data_store = self._ml_client.datastores.get(self._data_asset_name)
        if (
            data_store.protocol is None
            or data_store.account_name is None
            or data_store.endpoint is None
        ):
            raise ValueError(
                "Data store protocol, account name, and endpoint are required"
                " to create a blob storage URL."
            )
        return f"{data_store.protocol}://{data_store.account_name}.blob.{data_store.endpoint}/{data_store.name}"

    @abstractmethod
    def list_files(self, preserve_path: bool) -> list[str]:
        """
        Returns a list of files in the storage.

        :return: A list of file names.
        :rtype: list[str]
        """

    def get_mapping_from_files(self) -> dict[str, str]:
        files = self.list_files(self._preserve_path_in_mapping)
        logger.info("Create %s file mappings.", len(files))

        text_files = [file for file in files if is_textfile(file)]
        audio_files = [file for file in files if is_audiofile(file)]

        # # NB -> During load we've opted to store the transcript and audio files with different
        # #       names hence we need to map the transcript files to the audio files
        audio_files_index = {
            remove_extension(file).replace("audio", "transcript"): file
            for file in audio_files
        }

        mapping = {}

        for text_file in text_files:
            search_key = remove_extension(text_file)

            if search_key in audio_files_index:
                mapping[audio_files_index[search_key]] = text_file

            if self._max_files is not None and len(mapping) >= self._max_files:
                break

        logger.info("File mappings: %s", mapping)
        return mapping

    def get_audio_files_with_blob_url(self) -> list[str]:
        """
        Returns a list of audio files with the blob storage URL.

        SUGGESTION - We could amalgamate this with the
        get_audio_files method to reduce the number of iterations.

        :return: A list of audio file names.
        :rtype: list[str]
        """
        blob_storage_url = self.get_blob_storage_url()

        return [
            f"{blob_storage_url}/{get_filename(filename)}"
            for filename in self.get_audio_files()
        ]

    def get_audio_files(self) -> list[str]:
        audio_file_names_from_mapping = self.get_mapping_from_files().keys()
        return [
            file
            for file in self.list_files(self._preserve_path_in_mapping)
            if file in audio_file_names_from_mapping
        ]

    def _get_transcription_files(self) -> list[str]:
        """
        Retrieves a list of transcription files from storage.
        Filtered by the files_mapping

        Returns:
            A list of transcription files.

        """
        transcription_file_names_from_mapping = self.get_mapping_from_files().values()
        return [
            file
            for file in self.list_files(self._preserve_path_in_mapping)
            if file in transcription_file_names_from_mapping
        ]

    @abstractmethod
    def load_transcriptions(self) -> dict[str, str]:
        """
        Load transcriptions from the storage. This would typically
        be different for different storage types.

        :return: A dictionary of transcriptions.
        :rtype: dict[str, str]
        """

    @abstractmethod
    def load_audio_files(self) -> dict[str, AudioSegment]:
        """
        Load audio files from the storage. This would typically
        be different for different storage types.

        Returns:
            A dictionary of audio files.
        """

    @abstractmethod
    def create_audio_config(self, audio_file_name: str) -> AudioConfig:
        """
        Create an audio configuration for the audio file.

        :param audio_file_name: The name of the audio file.
        :type audio_file_name: str
        :return: An audio configuration.
        :rtype: AudioSegment
        """
