from itertools import chain
from rapidfuzz.distance import Levenshtein

from jiwer import transforms as tr
from jiwer.transformations import wer_default
from jiwer.process import (
    _apply_transform,
    _word2char,
)

from speech_experiment_accelerator.metrics import Metric, register_metric
from speech_experiment_accelerator.metrics.ground_truth_preprocess import (
    ignore_special_tokens,
    extract_entites,
    clear_transcription,
    PUNCTUATION_CHARACTERS,
)


@register_metric(Metric._SubsetComputeMeasures)
def _calculate_subset_edits(
    expected_transcription: str | list[str],
    actual_transcription: str | list[str],
    subset: None | list[str],
    expected_transcription_transform: tr.Compose | tr.AbstractTransform = wer_default,
    actual_transcription_transform: tr.Compose | tr.AbstractTransform = wer_default,
) -> dict:
    """
    Calculate word insertions, deletions, and substitutions for a given subset of words,
    and compute the word error rate (WER).

    Args:
        expected_transcription: The expected_transcription sentence(s).
        actual_transcription: The actual_transcription sentence(s).
        subset: List of words to consider for edit calculations.

    Returns:
        dict: Dictionary containing counts for insertions, deletions, substitutions, and WER.
    """
    if isinstance(expected_transcription, str):
        expected_transcription = [expected_transcription]
    if isinstance(actual_transcription, str):
        actual_transcription = [actual_transcription]
    if any(len(t) == 0 for t in expected_transcription):
        raise ValueError("one or more expected_transcriptions are empty strings")

    # pre-process expected_transcription and actual_transcription by applying transforms
    ref_transformed = _apply_transform(
        expected_transcription, expected_transcription_transform, is_reference=True
    )
    hyp_transformed = _apply_transform(
        actual_transcription, actual_transcription_transform, is_reference=False
    )

    if len(ref_transformed) != len(hyp_transformed):
        raise ValueError(
            "After applying the transforms on the expected_transcription and actual_transcription sentences, "
            f"their lengths must match. "
            f"Instead got {len(ref_transformed)} expected_transcription and "
            f"{len(hyp_transformed)} actual_transcription sentences."
        )

    vocabulary = set(chain(*ref_transformed, *hyp_transformed))
    word2char = dict(zip(vocabulary, range(len(vocabulary))))

    ref_as_chars, hyp_as_chars = _word2char(ref_transformed, hyp_transformed)

    if subset is None:
        subset_chars = set([chr(word2char[word]) for word in vocabulary])
    else:
        subset_chars = set(
            [chr(word2char[word]) for word in subset if word in word2char]
        )

    if not subset_chars:
        return {
            "substitutions": 0.0,
            "deletions": 0.0,
            "insertions": 0.0,
            "wer": 0.0,
        }

    num_hits, num_substitutions, num_deletions, num_insertions = 0, 0, 0, 0

    for expected_transcription_sentence, actual_transcription_sentence in zip(
        ref_as_chars, hyp_as_chars
    ):
        # Get the required edit operations to transform expected_transcription into actual_transcription
        edit_ops = Levenshtein.editops(
            expected_transcription_sentence, actual_transcription_sentence
        )

        # count the number of edits of each type
        substitutions = sum(
            1
            for op in edit_ops
            if op.tag == "replace"
            and expected_transcription_sentence[op.src_pos] in subset_chars
        )
        deletions = sum(
            1
            for op in edit_ops
            if op.tag == "delete"
            and expected_transcription_sentence[op.src_pos] in subset_chars
        )
        insertions = sum(
            1
            for op in edit_ops
            if op.tag == "insert"
            and actual_transcription_sentence[op.dest_pos] in subset_chars
        )
        hits = len(
            [c for c in expected_transcription_sentence if c in subset_chars]
        ) - (substitutions + deletions)

        # update state
        num_hits += hits
        num_substitutions += substitutions
        num_deletions += deletions
        num_insertions += insertions

    S, D, I, H = num_substitutions, num_deletions, num_insertions, num_hits
    wer = float(S + D + I) / float(max(1, H + S + D))

    return {
        "substitutions": S,
        "deletions": D,
        "insertions": I,
        "wer": wer,
    }


@register_metric(Metric.PunctuationSubstitutions)
@ignore_special_tokens
def punctuation_substitutions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return _calculate_subset_edits(
        expected_transcription, actual_transcription, PUNCTUATION_CHARACTERS
    )["substitutions"]


@register_metric(Metric.PunctuationInsertions)
@ignore_special_tokens
def punctuation_insertions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return _calculate_subset_edits(
        expected_transcription, actual_transcription, PUNCTUATION_CHARACTERS
    )["insertions"]


@register_metric(Metric.PunctuationDeletions)
@ignore_special_tokens
def punctuation_deletions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return _calculate_subset_edits(
        expected_transcription, actual_transcription, PUNCTUATION_CHARACTERS
    )["deletions"]


@register_metric(Metric.PunctuationErrorRate)
@ignore_special_tokens
def punctuation_error_rate(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return _calculate_subset_edits(
        expected_transcription, actual_transcription, PUNCTUATION_CHARACTERS
    )["wer"]


@register_metric(Metric.EntitySubstitutions)
def entity_substitutions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    entites = extract_entites(expected_transcription)
    expected_transcription = clear_transcription(expected_transcription)

    if not entites:
        return 0.0

    return _calculate_subset_edits(
        expected_transcription, actual_transcription, entites
    )["substitutions"]


@register_metric(Metric.EntityInsertions)
def entity_insertions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    entites = extract_entites(expected_transcription)
    expected_transcription = clear_transcription(expected_transcription)

    if not entites:
        return 0.0

    return _calculate_subset_edits(
        expected_transcription, actual_transcription, entites
    )["insertions"]


@register_metric(Metric.EntityDeletions)
def entity_deletions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    entites = extract_entites(expected_transcription)
    expected_transcription = clear_transcription(expected_transcription)

    if not entites:
        return 0.0

    return _calculate_subset_edits(
        expected_transcription, actual_transcription, entites
    )["deletions"]


@register_metric(Metric.EntityErrorRate)
def entity_error_rate(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    entites = extract_entites(expected_transcription)
    expected_transcription = clear_transcription(expected_transcription)

    if not entites:
        return 0.0

    return _calculate_subset_edits(
        expected_transcription, actual_transcription, entites
    )["wer"]
