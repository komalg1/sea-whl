from enum import Enum
from collections.abc import Iterable

import numpy as np

from speech_experiment_accelerator.metrics.registry.metric_registry import (
    metric_registry,
)
from speech_experiment_accelerator.utils.logger import get_logger
from nltk.tokenize.api import TokenizerI

logger = get_logger(__name__)


class Metric(Enum):
    WordErrorRate = "wer"
    MatchErrorRate = "mer"
    CharacterErrorRate = "cer"

    WordInformationLoss = "wil"
    WordInformationPreserved = "wip"

    Hits = "hits"

    WordSubstitutions = "substitutions"
    WordInsertions = "insertions"
    WordDeletions = "deletions"

    PunctuationSubstitutions = "punctuation_substitutions"
    PunctuationInsertions = "punctuation_insertions"
    PunctuationDeletions = "punctuation_deletions"
    PunctuationErrorRate = "per"

    EntitySubstitutions = "entity_substitutions"
    EntityInsertions = "entity_insertions"
    EntityDeletions = "entity_deletions"
    EntityErrorRate = "eer"

    PerfectMatch = "perfect_match"

    # Below this are supplementary metrics that are not directly used in the evaluation
    # IMPORTANT NOTE: Start names with an underscore to properly separate them from the main metrics.
    # Check get_metric_names() for more information.
    _JiwerComputeMeasures = "_compute_measures"
    _SubsetComputeMeasures = "_subset_compute_measures"

    @staticmethod
    def get_name(value: str) -> str:
        for metric in Metric:
            if metric.value == value:
                return metric.name
        return value


def __calculate_single_metric(
    expected_transcription: str | Iterable[str],
    actual_transcription: str | Iterable[str],
    metric_name: str,
    calculate_mean: bool = False,
    tokenizer: TokenizerI = None,
) -> float | list[float]:
    metric_function = metric_registry.get(metric_name)

    if metric_function is None:
        error = KeyError(f"Could not find metric function for {metric_name}.")
        logger.critical(error)
        raise error

    def tokenize_and_join(transcription: str | list[str]) -> str | list[str]:
        if tokenizer is None:
            return transcription
        if isinstance(transcription, str):
            return " ".join(tokenizer.tokenize(transcription))
        return [" ".join(tokenizer.tokenize(t)) for t in transcription]

    expected_transcription = tokenize_and_join(expected_transcription)
    actual_transcription = tokenize_and_join(actual_transcription)

    if isinstance(expected_transcription, str) and isinstance(
        actual_transcription, str
    ):
        return metric_function(expected_transcription, actual_transcription)
    if isinstance(expected_transcription, str) or isinstance(actual_transcription, str):
        error = ValueError(
            "Both true and pred should be strings if one of them is a string."
        )
        logger.critical(error)
        raise error
    elif isinstance(expected_transcription, Iterable) and isinstance(
        actual_transcription, Iterable
    ):
        metric_values = [
            metric_function(t, p)
            for t, p in zip(expected_transcription, actual_transcription)
        ]
        if calculate_mean:
            return np.mean(metric_values)
        else:
            return metric_values

    else:
        error = ValueError(
            "Both true and pred should be either strings or iterables of strings."
        )
        logger.critical(error)
        raise error


def calculate_metric(
    expected_transcription: str | Iterable[str],
    actual_transcription: str | Iterable[str],
    metric_name: str | Iterable[str],
    calculate_mean: bool = False,
    tokenizer: TokenizerI = None,
) -> float | list[float] | dict[str, float | list[float]]:
    if isinstance(metric_name, str):
        return __calculate_single_metric(
            expected_transcription,
            actual_transcription,
            metric_name,
            calculate_mean,
            tokenizer,
        )
    else:
        assert isinstance(
            metric_name, Iterable
        ), f"metric_name should be an iterable or string, got {metric_name}"
        return {
            name: __calculate_single_metric(
                expected_transcription,
                actual_transcription,
                name,
                calculate_mean,
                tokenizer,
            )
            for name in metric_name
        }


def get_metric_names() -> list[str]:
    return [name for name in metric_registry.keys() if not name.startswith("_")]
