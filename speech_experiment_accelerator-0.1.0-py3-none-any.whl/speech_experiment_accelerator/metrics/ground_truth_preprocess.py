from enum import Enum
from string import punctuation
from functools import wraps


PUNCTUATION_CHARACTERS = list(punctuation)


class TranscriptionSpecialTokens(Enum):
    EntityStart = "<entity>"
    EntityEnd = "</entity>"


def extract_entites(transcription: str) -> list[str]:
    entities = []
    entity_start_index = transcription.find(
        TranscriptionSpecialTokens.EntityStart.value
    )
    while entity_start_index != -1:
        entity_end_index = transcription.find(
            TranscriptionSpecialTokens.EntityEnd.value
        )
        if entity_end_index == -1:
            break
        entity = transcription[
            entity_start_index
            + len(TranscriptionSpecialTokens.EntityStart.value) : entity_end_index
        ]

        entity = entity.strip()

        entities.append(entity)
        transcription = transcription[
            entity_end_index + len(TranscriptionSpecialTokens.EntityEnd.value) :
        ]
        entity_start_index = transcription.find(
            TranscriptionSpecialTokens.EntityStart.value
        )

    return entities


def clear_transcription(transcription: str) -> str:
    for punctuation_character in TranscriptionSpecialTokens:
        transcription = transcription.replace(punctuation_character.value, "")
    return transcription


def ignore_special_tokens(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if args:
            # Clean the first argument
            new_args = (clear_transcription(args[0]),) + args[1:]
            return func(*new_args, **kwargs)
        return func(*args, **kwargs)

    return wrapper
