from speech_experiment_accelerator.metrics.registry.metric_registry import (
    register_metric,
)
from speech_experiment_accelerator.metrics.ground_truth_preprocess import (
    ignore_special_tokens,
)
from speech_experiment_accelerator.metrics.metrics import Metric


@register_metric(Metric.PerfectMatch)
@ignore_special_tokens
def perfect_match(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    if isinstance(expected_transcription, list):
        expected_transcription = " ".join(expected_transcription)
    if isinstance(actual_transcription, list):
        actual_transcription = " ".join(actual_transcription)
    return float(expected_transcription.lower() == actual_transcription.lower())
