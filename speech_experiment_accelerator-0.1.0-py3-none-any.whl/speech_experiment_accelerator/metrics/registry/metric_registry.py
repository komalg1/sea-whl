import functools
import threading
from collections import defaultdict

from speech_experiment_accelerator.utils.logger import get_logger

logger = get_logger(__name__)

metric_registry = {}

cache = {}
cache_locks = defaultdict(threading.Lock)


def register_metric(key, use_cache=True):
    def decorator(func):
        metric_registry[key.value] = func
        logger.debug(
            f"Registered {key} metric, {'with' if use_cache else 'without'} caching."
        )

        @functools.wraps(func)
        def wrapper(expected_transcription, actual_transcription, *args, **kwargs):
            if use_cache:
                cache_key = (
                    key,
                    tuple(expected_transcription),
                    tuple(actual_transcription),
                )

                with cache_locks[cache_key]:
                    if cache_key in cache:
                        return cache[cache_key]

            result = func(expected_transcription, actual_transcription, *args, **kwargs)

            if use_cache:
                with cache_locks[cache_key]:
                    cache[cache_key] = result

            return result

        return wrapper

    return decorator
