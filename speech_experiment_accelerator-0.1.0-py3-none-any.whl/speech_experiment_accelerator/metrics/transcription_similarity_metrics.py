from jiwer import compute_measures, wer, mer, wip, wil, cer
from speech_experiment_accelerator.metrics.registry.metric_registry import (
    register_metric,
)
from speech_experiment_accelerator.metrics.metrics import Metric
from speech_experiment_accelerator.metrics.ground_truth_preprocess import (
    ignore_special_tokens,
)


@register_metric(Metric.WordErrorRate)
@ignore_special_tokens
def word_error_rate(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return wer(expected_transcription, actual_transcription)


@register_metric(Metric.CharacterErrorRate)
@ignore_special_tokens
def character_error_rate(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return cer(expected_transcription, actual_transcription)


@register_metric(Metric.WordInformationLoss)
@ignore_special_tokens
def word_information_loss(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return wil(expected_transcription, actual_transcription)


@register_metric(Metric.WordInformationPreserved)
@ignore_special_tokens
def word_information_preserved(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return wip(expected_transcription, actual_transcription)


@register_metric(Metric.MatchErrorRate)
@ignore_special_tokens
def match_error_rate(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return mer(expected_transcription, actual_transcription)


@register_metric(Metric._JiwerComputeMeasures)
@ignore_special_tokens
def __jiwer_compute_measures(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return compute_measures(expected_transcription, actual_transcription)


@register_metric(Metric.Hits)
@ignore_special_tokens
def hits(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return __jiwer_compute_measures(expected_transcription, actual_transcription)[
        "hits"
    ]


@register_metric(Metric.WordSubstitutions)
@ignore_special_tokens
def word_substitutions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return __jiwer_compute_measures(expected_transcription, actual_transcription)[
        "substitutions"
    ]


@register_metric(Metric.WordInsertions)
@ignore_special_tokens
def word_insertions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return __jiwer_compute_measures(expected_transcription, actual_transcription)[
        "insertions"
    ]


@register_metric(Metric.WordDeletions)
@ignore_special_tokens
def word_deletions(
    expected_transcription: str | list[str], actual_transcription: str | list[str]
) -> float:
    return __jiwer_compute_measures(expected_transcription, actual_transcription)[
        "deletions"
    ]
