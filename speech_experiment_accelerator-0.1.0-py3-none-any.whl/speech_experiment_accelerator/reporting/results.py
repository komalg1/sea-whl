import json
from datetime import datetime

from speech_experiment_accelerator.reporting.markdown import MarkdownFile
from speech_experiment_accelerator.config import Config


def record_results(config: Config, metrics: dict):
    if config.reporting.enabled:
        date_time = datetime.now()
        date_time_string = date_time.strftime("%Y-%m-%d--%H-%M-%S")

        markdown_file = MarkdownFile(
            config.reporting.folder, f"{date_time_string}-results.md"
        )
        __add_title(date_time, markdown_file)
        __add_problem_statement(markdown_file)
        __add_hypothesis(markdown_file)
        __add_config(config, markdown_file)
        __add_metrics(markdown_file, metrics)
        __add_conclusion(markdown_file)
        markdown_file.write()


def __add_title(date_time, markdown_file):
    markdown_file.add_header("Experiment Results", 1)
    markdown_file.add_new_line()
    markdown_file.add_list(
        [
            f"Date: {date_time.strftime('%Y-%m-%d')}",
            f"Time: {date_time.strftime('%H:%M:%S')}",
        ]
    )
    markdown_file.add_new_line()


def __add_problem_statement(markdown_file):
    markdown_file.add_header("Problem Statement", 2)
    markdown_file.add_text("What problem are we trying to solve?", "*")
    markdown_file.add_new_line()


def __add_hypothesis(markdown_file):
    markdown_file.add_header("Hypothesis", 2)
    markdown_file.add_text("What was the hypothesis for this experiment?", "*")
    markdown_file.add_new_line()


def __add_config(config, markdown_file):
    markdown_file.add_header("Config", 2)
    markdown_file.add_code(json.dumps(config.dict(), indent=4), "json")
    markdown_file.add_new_line()


def __add_metrics(markdown_file, metrics):
    markdown_file.add_header("Metrics", 2)
    metric_data = [["Metric", "Value"]]
    for metric, value in metrics.items():
        metric_data.append([metric, value])
    markdown_file.add_table(metric_data)
    markdown_file.add_new_line()


def __add_conclusion(markdown_file):
    markdown_file.add_header("Conclusion", 2)
    markdown_file.add_text(
        "What was the conclusion from this experiment and what are the next steps?", "*"
    )
