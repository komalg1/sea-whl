import os


class MarkdownFile:
    """
    Class to create a markdown file

    Unit tested through its use by the results.py file.
    """

    __contents = ""

    def __init__(self, folder: str, filename: str):
        self.folder = folder
        self.filename = filename

    def add_header(self, header: str, level: int):
        """
        Add a header to the markdown file
        :param header: The header text
        :param level: The level of the header (1-6) E.g 2 will prepend ## to the header
        :return: None
        """
        self.__contents += f"{'#' * level} {header}\n"

    def add_new_line(self):
        """
        Add a new line to the markdown file
        :return: None
        """
        self.__contents += "\n"

    def add_list(self, items: list[str]):
        """
        Add a list to the markdown file with each item on a new line prepended with a dash
        :param items: The list of items to add
        :return: None
        """
        for item in items:
            self.__contents += f"- {item}\n"

    def add_text(self, text: str, style: str = ""):
        """
        Add text to the markdown file
        :param text: The text to add
        :param style: The style to apply to the text e.g. *, _ etc. This will be prepended and appended to the text.
        :return: None
        """
        self.__contents += f"{style}{text}{style}\n"

    def add_code(self, code: str, language: str = ""):
        """
        Add code block to the markdown file
        :param code: The code to add
        :param language: The language of the code block e.g. python, java, json etc.
        :return: None
        """
        self.__contents += f"```{language}\n{code}\n```\n"

    def add_table(self, data: list[list[str]]):
        """
        Add a table to the markdown file
        :param data: The table data. The first row should be the header row and the rest should be the data rows.
        :return: None
        """
        self.__add_table_header(data)
        for row in data[1:]:
            self.__contents += "|"
            for column in row:
                self.__contents += f" {column} |"
            self.add_new_line()

    def __add_table_header(self, data):
        self.__contents += "|"
        for column in data[0]:
            self.__contents += f" {column} |"
        self.add_new_line()
        self.__contents += "|"
        for _ in data[0]:
            self.__contents += " --- |"
        self.add_new_line()

    def write(self):
        """
        Write the markdown file to the disk in the specified folder with the specified filename.
        :return: None
        """
        filepath = f"{self.folder}/{self.filename}"
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, "w") as file:
            file.write(self.__contents)
