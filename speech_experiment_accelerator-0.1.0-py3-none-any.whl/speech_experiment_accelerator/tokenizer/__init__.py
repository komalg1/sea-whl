# flake8: noqa
import nltk

nltk.download("punkt")

from speech_experiment_accelerator.tokenizer.regexp_tokenizer import RegexpTokenizer
from speech_experiment_accelerator.tokenizer.split_tokenizer import SplitTokenizer
