from nltk.tokenize.api import TokenizerI


class SplitTokenizer(TokenizerI):
    def __init__(self, split_char: str = " ", *args, **kwargs):
        self.split_char = split_char

    def tokenize(self, s: str):
        return [item for item in s.split(self.split_char) if item]
