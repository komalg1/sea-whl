from nltk.tokenize.api import TokenizerI
import re

from speech_experiment_accelerator.metrics.ground_truth_preprocess import (
    TranscriptionSpecialTokens,
    PUNCTUATION_CHARACTERS,
)


class RegexpTokenizer(TokenizerI):
    def __init__(
        self,
        pattern=r"\w+|[^\w\s]",
        gaps=False,
        lower_case=True,
        remove_punctuation=True,
    ):
        special_tokens = [
            re.escape(token.value) for token in TranscriptionSpecialTokens
        ]
        special_tokens_pattern = "|".join(special_tokens)
        self.pattern = f"({special_tokens_pattern})|({pattern})"
        self.gaps = gaps
        self.lower_case = lower_case
        self.remove_punctuation = remove_punctuation

    def tokenize(self, s):

        if self.lower_case:
            s = s.lower()

        tokens = re.findall(self.pattern, s)

        selected_tokens = [token[0] if token[0] else token[1] for token in tokens]

        if self.remove_punctuation:
            selected_tokens = [
                token
                for token in selected_tokens
                if token not in PUNCTUATION_CHARACTERS
            ]

        return selected_tokens
