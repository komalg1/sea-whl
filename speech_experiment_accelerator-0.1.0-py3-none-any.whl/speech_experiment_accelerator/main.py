import click

from speech_experiment_accelerator.commands import job, model, run, register_datastore

commands = [job, model, run, register_datastore]


@click.group()
def main():
    pass


for cmd in commands:
    main.add_command(cmd)


if __name__ == "__main__":
    main()
