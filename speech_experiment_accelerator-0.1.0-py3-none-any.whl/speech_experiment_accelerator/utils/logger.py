import logging
import os


def _set_logging_config():

    _cached_logging_level = os.getenv("LOGGING_LEVEL", "INFO")

    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    logging.basicConfig(format=log_format, level=_cached_logging_level)


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    return logger


_set_logging_config()
