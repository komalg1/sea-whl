from typing import Dict

from azure.ai.ml import Input, MLClient
from azure.ai.ml.constants import AssetTypes, InputOutputModes
from azure.ai.ml.entities import WorkspaceConnection
from azure.core.exceptions import ResourceNotFoundError

from speech_experiment_accelerator.config import ExperimentConfig
from speech_experiment_accelerator.exceptions import NotFoundException


def get_connection_details(
    ml_client: MLClient, connection_name: str
) -> WorkspaceConnection:
    connection = ml_client.connections.get(connection_name, populate_secrets=True)

    if isinstance(connection, WorkspaceConnection):
        return connection

    raise ValueError(f"Connection {connection_name} is not a WorkspaceConnection.")


def get_job_input(
    ml_client: MLClient, experiment_config: ExperimentConfig
) -> Dict[str, Input] | None:
    if experiment_config.data_asset_name:
        try:
            data_asset = ml_client.data.get(
                experiment_config.data_asset_name,
                version=experiment_config.data_asset_version,
                label=(
                    "latest" if experiment_config.data_asset_version is None else None
                ),
            )
        except ResourceNotFoundError as exc:
            raise NotFoundException(
                (
                    f"Unable to get {experiment_config.data_asset_name}:{experiment_config.data_asset_version} "
                    "data asset. Please check this Data Asset exists."
                )
            ) from exc

        return {
            "data": Input(
                path=data_asset.id,
                type=AssetTypes.URI_FOLDER,
                mode=InputOutputModes.RO_MOUNT,
            )
        }

    return None
