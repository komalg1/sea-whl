import os

TEXT_FILE_EXTENSIONS = {"txt", "cha", "trs", "csv"}
AUDIO_FILE_EXTENSIONS = {"wav", "mp3", "flac"}


def get_repo_root(marker_file="setup.py"):
    current_dir = os.path.abspath(os.curdir)
    while current_dir != os.path.dirname(current_dir):
        if os.path.exists(os.path.join(current_dir, marker_file)):
            return current_dir
        current_dir = os.path.dirname(current_dir)
    return None


def _write_to_file(config_yaml: str, *path: str):
    full_path = os.path.join(*path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(config_yaml)


def get_filename(path: str) -> str:
    """
    Get the filename from a path or url. For example:
    - get_filename("http://example.com/file.txt") -> "file.txt"
    - get_filename("/path/to/file.txt") -> "file.txt"
    - get_filename("file.txt") -> "file.txt"

    :param path: The path or url of the file
    :return: The filename
    """
    return path.split("/")[-1]


def remove_extension(file_name: str) -> str:
    extension = file_name.split(".")[-1]
    if extension == file_name:
        return file_name
    else:
        return file_name[: -len(extension) - 1]


def is_textfile(file_name: str) -> bool:
    return file_name.split(".")[-1].lower() in TEXT_FILE_EXTENSIONS


def is_audiofile(file_name: str) -> bool:
    return file_name.split(".")[-1].lower() in AUDIO_FILE_EXTENSIONS
