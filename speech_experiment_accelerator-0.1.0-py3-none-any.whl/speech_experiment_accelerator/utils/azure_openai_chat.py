from openai import AzureOpenAI
from speech_experiment_accelerator.config import AzureOpenAIConfig
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential, get_bearer_token_provider
from openai.types.chat import (
    ChatCompletionMessageParam,
    ChatCompletionUserMessageParam,
    ChatCompletionSystemMessageParam,
    ChatCompletion,
)
from speech_experiment_accelerator.utils.machine_learning_client import (
    get_connection_details,
)

TOKEN_SCOPE = "https://cognitiveservices.azure.com/.default"


class AzureOpenAIChat:

    def __init__(self, config: AzureOpenAIConfig):

        ml_client = MLClient.from_config(credential=DefaultAzureCredential())

        connection_details = get_connection_details(ml_client, config.connection_name)

        self._client = AzureOpenAI(
            api_version=config.api_version,
            azure_endpoint=connection_details.endpoint,
            azure_ad_token_provider=get_bearer_token_provider(
                DefaultAzureCredential(), TOKEN_SCOPE
            ),
        )

        self._model = config.llm_deployment

    def chat(self, system_prompt: str, user_prompt: str) -> str | None:

        messages: list[ChatCompletionMessageParam] = [
            ChatCompletionSystemMessageParam(
                role="system",
                content=system_prompt,
            ),
            ChatCompletionUserMessageParam(
                role="user",
                content=user_prompt,
            ),
        ]

        response = self._client.chat.completions.create(
            model=self._model, messages=messages
        )

        return self._extract_first_assistant_message(response)

    def _extract_first_assistant_message(self, data: ChatCompletion) -> str | None:
        for choice in data.choices:
            if choice.message.role == "assistant":
                return choice.message.content
        return None
