import io

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.utils.logger import get_logger


logger = get_logger(__name__)


class TemplateExperiment(BaseExperiment):
    """
    A template experiment class that serves as a base for creating custom experiments.

    Args:
        config (Config): The experiment configuration.
        azureml_config_file (io.TextIOWrapper | None, optional): The Azure ML configuration
          file. Defaults to None.
    """

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(config, azureml_config_file, input_path)
        # any of your individual experiment's attributes go here

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):
        """
        Runs the experiment and returns the true and predicted values.

        Returns:
            tuple: A tuple containing the true and predicted values.
        """
        result = []

        # your experiment code goes here
        # input_path contains a series of files xx_transcript.txt and xx_audio.wav where xx
        # is a number

        # result is a list that contains a tuple (true, predicted)
        # example result = [('I am expecting this', 'I am expecting this, but I got this')]

        y_true, y_pred = zip(*result)
        return y_true, y_pred
