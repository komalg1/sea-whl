import io

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)
from speech_experiment_accelerator.stt_core.azure.speech_service.azure_speech_service_realtime import (
    AzureSpeechServiceRealtime,
)
from speech_experiment_accelerator.utils.logger import get_logger

logger = get_logger(__name__)


class RealtimeTranscriptionExperiment(BaseExperiment):
    """
    Realtime transcription experiment class that uses Azure Speech Service's realtime transcription
    SDK. This is an example implementation of the BaseExperiment class.
    """

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(config, azureml_config_file, input_path)

        speech_client = AzureSpeechClient.from_connection(self._ml_client, self._config)
        self.azure_speech_stt_realtime = AzureSpeechServiceRealtime(
            speech_client, self._storage_client
        )

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):

        y_pred = []  # these are the transcriptions created by this experiment
        y_true = []  # these are the expected transcriptions from the data set

        transcriptions = self._storage_client.load_transcriptions()

        for audio, expected_transcript in audio_to_transcript_mapping.items():
            y_true.append(transcriptions[expected_transcript])
            y_pred.append(self.azure_speech_stt_realtime.transcribe_file(audio))

        return (y_true, y_pred)
