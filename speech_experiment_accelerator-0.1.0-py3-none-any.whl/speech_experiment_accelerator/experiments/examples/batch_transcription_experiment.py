import io
import mlflow

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)
from speech_experiment_accelerator.stt_core.azure.speech_service.azure_speech_service_batch import (
    AzureSpeechServiceBatch,
)
from speech_experiment_accelerator.utils.logger import get_logger


logger = get_logger(__name__)


class BatchTranscriptionExperiment(BaseExperiment):
    """
    Batch transcription experiment class that uses Azure Speech to Text service to transcribe
    a batch of audio files.
    This is an example implementation of the BaseExperiment class.

    Attributes:
        azure_speech_stt_batch (AzureSpeechServiceBatch): Azure Speech to Text batch service.
    """

    azure_speech_stt_batch: AzureSpeechServiceBatch

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(
            config, azureml_config_file, input_path, preserve_path_in_mapping=False
        )
        speech_client = AzureSpeechClient.from_connection(self._ml_client, self._config)
        self.azure_speech_stt_batch = AzureSpeechServiceBatch(
            config, speech_client, self._storage_client
        )

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):
        result = self.azure_speech_stt_batch.transcribe_blob_url(
            audio_to_transcript_mapping,
        )

        report = result.report
        mlflow.log_metric(
            "SuccessfulTranscriptionsCount",
            report.get("successfulTranscriptionsCount", 0),
        )
        mlflow.log_metric(
            "FailedTranscriptionsCount", report.get("failedTranscriptionsCount", 0)
        )

        y_true, y_pred = zip(*result.transcriptions)
        return y_true, y_pred
