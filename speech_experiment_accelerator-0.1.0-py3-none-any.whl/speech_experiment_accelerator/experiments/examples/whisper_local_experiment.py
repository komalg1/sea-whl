import io
from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.stt_core.whisper import (
    Whisper,
)

logger = get_logger(__name__)


class WhisperLocalExperiment(BaseExperiment):
    """
    A template experiment class that serves as a base for creating custom experiments.

    Args:
        config (Config): The experiment configuration.
        azureml_config_file (io.TextIOWrapper | None, optional): The Azure ML configuration file. Defaults to None.
    """

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(config, azureml_config_file, input_path)
        self._whisper = Whisper(self._storage_client)

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):
        """
        Runs the experiment and returns the true and predicted values.

        Returns:
            tuple: A tuple containing the true and predicted values.
        """

        result = []

        # result is a list that contains a tuple (true, predicted)
        # example result = [('I am expecting this', 'I am expecting this, but I got this')]
        transcriptions = self._storage_client.load_transcriptions()
        logger.info("Transcriptions: %s", transcriptions)
        audio_files = self._storage_client.load_audio_files()
        for key, value in audio_to_transcript_mapping.items():
            true_value = transcriptions[value]
            predicted = self._whisper.transcribe(audio_files[key])

            logger.info("True value: %s | Predicted value: %s", true_value, predicted)

            result.append((true_value, predicted))

        y_true, y_pred = zip(*result)
        return y_true, y_pred
