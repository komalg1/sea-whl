import io
import mlflow

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.stt_core.azure.azure_speech_client import (
    AzureSpeechClient,
)
from speech_experiment_accelerator.stt_core.azure.speech_service.azure_speech_service_batch import (
    AzureSpeechServiceBatch,
)
from speech_experiment_accelerator.utils.azure_openai_chat import AzureOpenAIChat
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.exceptions import ValidationException


logger = get_logger(__name__)


class BatchTranscriptionWithTranslationExperiment(BaseExperiment):
    """
    Batch transcription experiment class that uses Azure Speech to Text
    service to transcribe a batch of audio files.
    This example includes translation of the true transcripts into a language of your choice.

    This experiment covers cases such as Swiss-German where the transcription result of
    Swiss-German audio is returned in High German.
    This experiment translates the true transcriptions from Swiss German to High German so that
    metrics can be calculated while comparing sentences in the same language.

    Attributes:
        azure_speech_stt_batch (AzureSpeechServiceBatch): Azure Speech to Text batch service.
    """

    azure_speech_stt_batch: AzureSpeechServiceBatch

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(
            config, azureml_config_file, input_path, preserve_path_in_mapping=False
        )

        speech_client = AzureSpeechClient.from_connection(self._ml_client, self._config)
        self.azure_speech_stt_batch = AzureSpeechServiceBatch(
            config, speech_client, self._storage_client
        )
        if config.azure_openai is None:
            raise ValidationException("Dataset configuration is missing")
        self.azure_openai_client = AzureOpenAIChat(config.azure_openai)

        if (
            config.experiment.custom_config is None
            or config.experiment.custom_config["target_language"] is None
        ):
            raise ValidationException(
                'experiment.custom_config["target_language"] is required for this experiment'
            )

        self.target_language = config.experiment.custom_config["target_language"]

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):
        result = self.azure_speech_stt_batch.transcribe_blob_url(
            audio_to_transcript_mapping,
        )

        report = result.report
        mlflow.log_metric(
            "SuccessfulTranscriptionsCount",
            report.get("successfulTranscriptionsCount", 0),
        )
        mlflow.log_metric(
            "FailedTranscriptionsCount", report.get("failedTranscriptionsCount", 0)
        )

        y_true, y_pred = zip(*result.transcriptions)

        y_true_translated = []
        y_pred_updated = []

        for index, text in enumerate(y_true):
            translated_text = self._translate(self.target_language, text)

            if translated_text is not None:
                y_true_translated.append(translated_text)
                y_pred_updated.append(y_pred[index])

        return y_true_translated, y_pred_updated

    def _translate(self, target_language, input) -> str | None:
        user_prompt = f"Translate this to {target_language}: {input}."
        "Do not include anything else in your response except the translated sentence."

        system_prompt = "You are an AI assistant that helps people find information."

        try:
            translated_text = self.azure_openai_client.chat(
                system_prompt=system_prompt, user_prompt=user_prompt
            )
            return translated_text
        except Exception as e:
            logger.error(f"A problem occurred when translating: {e}")

        return None
