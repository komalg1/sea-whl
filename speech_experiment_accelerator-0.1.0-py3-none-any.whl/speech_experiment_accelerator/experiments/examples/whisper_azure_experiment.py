import io
import time

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.experiments.base_experiment import BaseExperiment
from speech_experiment_accelerator.utils.logger import get_logger
from speech_experiment_accelerator.stt_core.azure.whisper.azure_whisper import (
    AzureWhisper,
)

logger = get_logger(__name__)


class WhisperAzureExperiment(BaseExperiment):
    """
    Azure Open AI Whisper experiment class. Please note that Whisper in Azure can only
    be deployed in certain regions.
    This is an example implementation of the Base Experiment class.

    Args:
        config (Config): The experiment configuration.
        azureml_config_file (io.TextIOWrapper | None, optional): The Azure ML configuration
          file. Defaults to None.
    """

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
    ):
        super().__init__(config, azureml_config_file, input_path)
        self._whisper = AzureWhisper(config.azure_openai, self._storage_client)

    def run_experiment(self, audio_to_transcript_mapping: dict[str, str]):
        """
        Runs the experiment and returns the true and predicted values.

        Returns:
            tuple: A tuple containing the true and predicted values.
        """

        result = []

        # result is a list that contains a tuple (true, predicted)
        # example result = [('I am expecting this', 'I am expecting this, but I got this')]

        transcriptions = self._storage_client.load_transcriptions()
        audio_files = self._storage_client.load_audio_files()

        rate_limit = 3.0 / 60  # requests per second

        for key, value in audio_to_transcript_mapping.items():

            true_value = transcriptions[value]

            predicted = self._whisper.transcribe(audio_files[key])

            time.sleep(1.0 / rate_limit)

            logger.info("True value: %s | Predicted value: %s", true_value, predicted)

            result.append((true_value, predicted))

        y_true, y_pred = zip(*result)
        return y_true, y_pred
