import io
import logging
import os
import time
from abc import ABC, abstractmethod
from typing import Tuple

import mlflow
import pandas as pd
from azure.ai.ml import MLClient
from azure.identity import DefaultAzureCredential

from speech_experiment_accelerator.config import Config
from speech_experiment_accelerator.metrics import (
    Metric,
    calculate_metric,
    get_metric_names,
)
from speech_experiment_accelerator.reporting.results import record_results
from speech_experiment_accelerator.storage.azure_ml_storage_client import (
    AzureMLStorageClient,
)
from speech_experiment_accelerator.storage.local_storage_client import (
    LocalStorageClient,
)
from speech_experiment_accelerator.storage.storage_base import StorageBase
from speech_experiment_accelerator.tokenizer import RegexpTokenizer

logging.basicConfig(level=logging.INFO)

logger = logging.getLogger(__name__)


class BaseExperiment(ABC):
    """
    Base class for all experiments. This class provides the basic structure for running
    an experiment, calculating the metrics and logging them to MLFlow. The
    run_experiment method needs to be implemented in the child class.

    Attributes:
        _config (Config): Config object containing the configuration for the experiment.
        _ml_client (MLClient): MLClient object for interacting with Azure ML.
        _storage_client (StorageBase): Storage client for interacting with storage.
    """

    _config: Config
    _ml_client: MLClient
    _storage_client: StorageBase

    def __init__(
        self,
        config: Config,
        azureml_config_file: io.TextIOWrapper | None = None,
        input_path: str | None = None,
        preserve_path_in_mapping=True,
    ):
        self._config = config
        self._ml_client = self.__create_ml_client(azureml_config_file)
        self.__set_mlflow_tracking_uri()
        self._storage_client = self.__create_storage_client(
            input_path, preserve_path_in_mapping
        )

    def __create_storage_client(
        self, input_path: str | None, preserve_path_in_mapping: bool
    ) -> StorageBase:
        """
        Create a storage client based on the input path. When running as a job we will have
        a mounted path, so we create a LocalStorageClient. When running as a local
        experiment we will have an AzureML path, so we create an AzureMLStorageClient.

        :return: AzureMLStorageClient | LocalStorageClient
        """
        if input_path is None:
            return AzureMLStorageClient(
                self._ml_client,
                self._config.experiment.data_asset_name,
                self._config.experiment.data_asset_version,
                preserve_path_in_mapping,
                self._config.experiment.max_files,
            )

        return LocalStorageClient(
            self._ml_client,
            input_path,
            self._config.experiment.data_asset_name,
            preserve_path_in_mapping,
            self._config.experiment.max_files,
        )

    def __create_ml_client(self, azureml_config_file: str | None) -> MLClient:
        azureml_config_file = (
            azureml_config_file.read() if azureml_config_file else None
        )
        return MLClient.from_config(
            credential=DefaultAzureCredential(), path=azureml_config_file
        )

    def __set_mlflow_tracking_uri(self) -> None:
        """
        Sets the MLflow tracking URI.
        :return: None
        """
        mlflow_tracking_uri = self._ml_client.workspaces.get(
            self._ml_client.workspace_name
        ).mlflow_tracking_uri
        mlflow.set_tracking_uri(mlflow_tracking_uri)

    def run(self) -> None:
        """
        Run the experiment, calculate metrics and log them to MLFlow.
        :return: None
        """

        start_time = time.time()

        y_true, y_pred = self.run_experiment(
            self._storage_client.get_mapping_from_files()
        )

        total_time = time.time() - start_time

        mlflow.log_metric("TotalExperimentTime", total_time)

        metrics = self.calculate_metrics(y_true, y_pred)

        self.log_to_mlflow(metrics)

        record_results(self._config, metrics)

        self.save_transcriptions(y_true, y_pred)

    def save_transcriptions(self, y_true: list[str], y_pred: list[str]) -> None:
        """
        Save the true and predicted transcriptions to the output path.
        :param y_true: List strings containing the actual transcriptions.
        :param y_pred: List strings containing
        :return: None
        """
        output_path = self._config.reporting.folder

        df = pd.DataFrame({"True": y_true, "Predicted": y_pred})
        df.to_csv(os.path.join(output_path, "transcriptions.csv"), index=False)

    def calculate_metrics(
        self, y_true: list[str], y_pred: list[str]
    ) -> float | list[float] | dict[str, float | list[float]]:
        """
        Calculate metrics for the given true and predicted transcriptions.
        :param y_true: List strings containing the actual transcriptions. This needs to be ordered in alignment with
                       y_pred.
        :param y_pred: List strings containing the predicted transcriptions. This needs to be ordered in alignment with
                       y_true.
        :return: Dict containing the calculated metrics.
        """
        metrics_names = get_metric_names()

        metrics = calculate_metric(
            y_true,
            y_pred,
            metrics_names,
            calculate_mean=True,
            tokenizer=RegexpTokenizer(),
        )

        punctuation_metrics = calculate_metric(
            y_true,
            y_pred,
            [
                Metric.PunctuationSubstitutions.value,
                Metric.PunctuationInsertions.value,
                Metric.PunctuationDeletions.value,
                Metric.PunctuationErrorRate.value,
            ],
            calculate_mean=True,
            tokenizer=RegexpTokenizer(remove_punctuation=False),
        )

        metrics.update(punctuation_metrics)

        logger.info("Transcription metrics: %s", metrics)

        return metrics

    def log_to_mlflow(
        self, metrics: float | list[float] | dict[str, float | list[float]]
    ) -> None:
        """
        Log the given metrics to MLFlow.
        :param metrics: Dict containing the metrics to log.
        :return: None
        """
        for metric_name, metric_value in metrics.items():
            fancy_metric_name = Metric.get_name(metric_name)
            mlflow.log_metric(fancy_metric_name, metric_value)

    @abstractmethod
    def run_experiment(
        self, audio_to_transcript_mapping: dict[str, str]
    ) -> Tuple[list[str], list[str]]:
        """
        Run the experiment and return the true and predicted transcriptions. An example
        implementation can be found in the batch_transcription_experiment.py file.
        :return: Tuple containing the true and predicted transcriptions.
        """
