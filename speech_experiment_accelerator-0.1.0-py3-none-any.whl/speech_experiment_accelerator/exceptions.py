class MultipleFoundException(Exception):
    pass


class NotFoundException(Exception):
    pass


class ResourceExistsException(Exception):
    pass


class TrainingFailureException(Exception):
    pass


class ValidationException(Exception):
    pass
